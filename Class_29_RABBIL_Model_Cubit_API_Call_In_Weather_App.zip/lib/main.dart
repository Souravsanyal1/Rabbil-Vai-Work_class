import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/cubit/weather_cubit.dart';
import 'package:untitled/repo/weather_repo.dart';
import 'package:untitled/screens/weather_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget{

  Widget build(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context)=>WeatherCubit(WeatherRepo())
          )
        ],
        child: MaterialApp(home: WeatherScreen())
    );
  }

}



/*



 */

